# Frontend useEffect audit

- Total useEffect occurrences: 41
- Effects with empty dependency array: 36
- Files with useEffect + fetch/axios/timers/listeners (heuristic): 7

## Findings
- Review effects with side effects; prefer React Query or custom hooks for data fetching.
/Users/nasserelbacha/Documents/Dinamic sistems/dinamic-localizador/frontend/src/context/AuthContext.tsx:24:  useEffect(() => {
/Users/nasserelbacha/Documents/Dinamic sistems/dinamic-localizador/frontend/src/context/AuthContext.tsx:30:  useEffect(() => {
/Users/nasserelbacha/Documents/Dinamic sistems/dinamic-localizador/frontend/src/context/CompanyContext.tsx:80:  useEffect(() => {
/Users/nasserelbacha/Documents/Dinamic sistems/dinamic-localizador/frontend/src/context/CompanyContext.tsx:90:  useEffect(() => {
/Users/nasserelbacha/Documents/Dinamic sistems/dinamic-localizador/frontend/src/test/render-page.tsx:101:    useEffect(() => {
/Users/nasserelbacha/Documents/Dinamic sistems/dinamic-localizador/frontend/src/components/lookups/EntityMultiSelects.tsx:58:  useEffect(() => {
/Users/nasserelbacha/Documents/Dinamic sistems/dinamic-localizador/frontend/src/components/lookups/EntityMultiSelects.tsx:62:  useEffect(() => {
/Users/nasserelbacha/Documents/Dinamic sistems/dinamic-localizador/frontend/src/components/operations/OperationForm.tsx:125:  useEffect(() => {
/Users/nasserelbacha/Documents/Dinamic sistems/dinamic-localizador/frontend/src/components/operations/OperationForm.tsx:129:  useEffect(() => {
/Users/nasserelbacha/Documents/Dinamic sistems/dinamic-localizador/frontend/src/components/operations/OperationForm.tsx:143:  useEffect(() => {
/Users/nasserelbacha/Documents/Dinamic sistems/dinamic-localizador/frontend/src/components/operations/OperationForm.tsx:182:  useEffect(() => {
/Users/nasserelbacha/Documents/Dinamic sistems/dinamic-localizador/frontend/src/components/operations/OperationTeamSection.tsx:88:  useEffect(() => {
/Users/nasserelbacha/Documents/Dinamic sistems/dinamic-localizador/frontend/src/components/common/EntityMultiSelect.tsx:216:  useEffect(() => {
/Users/nasserelbacha/Documents/Dinamic sistems/dinamic-localizador/frontend/src/components/work-teams/WorkTeamMemberMultiSelect.tsx:49:  useEffect(() => {
/Users/nasserelbacha/Documents/Dinamic sistems/dinamic-localizador/frontend/src/components/work-teams/WorkTeamForm.tsx:54:  useEffect(() => {
/Users/nasserelbacha/Documents/Dinamic sistems/dinamic-localizador/frontend/src/components/work-teams/WorkTeamForm.tsx:58:  useEffect(() => {
/Users/nasserelbacha/Documents/Dinamic sistems/dinamic-localizador/frontend/src/components/services/ServiceForm.tsx:62:  useEffect(() => {
/Users/nasserelbacha/Documents/Dinamic sistems/dinamic-localizador/frontend/src/components/services/ServiceForm.tsx:66:  useEffect(() => {
/Users/nasserelbacha/Documents/Dinamic sistems/dinamic-localizador/frontend/src/components/services/location-picker/hooks/useLocationPickerState.ts:83:  useEffect(() => {
/Users/nasserelbacha/Documents/Dinamic sistems/dinamic-localizador/frontend/src/components/services/location-picker/hooks/useLocationPickerState.ts:154:  useEffect(() => {
/Users/nasserelbacha/Documents/Dinamic sistems/dinamic-localizador/frontend/src/components/services/location-picker/hooks/useLocationPickerState.ts:319:  useEffect(() => {
/Users/nasserelbacha/Documents/Dinamic sistems/dinamic-localizador/frontend/src/components/services/location-picker/hooks/useServiceLocationMapView.ts:31:  useEffect(() => {
/Users/nasserelbacha/Documents/Dinamic sistems/dinamic-localizador/frontend/src/components/services/location-picker/hooks/useServiceLocationMapView.ts:42:  useEffect(() => {
/Users/nasserelbacha/Documents/Dinamic sistems/dinamic-localizador/frontend/src/components/services/location-picker/hooks/useServiceLocationMapView.ts:130:  useEffect(() => {
/Users/nasserelbacha/Documents/Dinamic sistems/dinamic-localizador/frontend/src/components/employees/EmployeeForm.tsx:73:  useEffect(() => {
/Users/nasserelbacha/Documents/Dinamic sistems/dinamic-localizador/frontend/src/components/employees/EmployeeForm.tsx:77:  useEffect(() => {
/Users/nasserelbacha/Documents/Dinamic sistems/dinamic-localizador/frontend/src/components/employees/EmployeeCategorySelect.test.tsx:90:  useEffect(() => {
/Users/nasserelbacha/Documents/Dinamic sistems/dinamic-localizador/frontend/src/hooks/useTableUrlState.ts:106:  useEffect(() => {
/Users/nasserelbacha/Documents/Dinamic sistems/dinamic-localizador/frontend/src/hooks/useTableUrlState.ts:128:  useEffect(() => {
/Users/nasserelbacha/Documents/Dinamic sistems/dinamic-localizador/frontend/src/hooks/useTableUrlState.ts:147:  useEffect(() => {
/Users/nasserelbacha/Documents/Dinamic sistems/dinamic-localizador/frontend/src/hooks/useTableUrlState.ts:211:  useEffect(() => {
/Users/nasserelbacha/Documents/Dinamic sistems/dinamic-localizador/frontend/src/hooks/useDebouncedValue.ts:29:  useEffect(() => {
/Users/nasserelbacha/Documents/Dinamic sistems/dinamic-localizador/frontend/src/hooks/useUnsavedChangesGuard.ts:25:  useEffect(() => {
/Users/nasserelbacha/Documents/Dinamic sistems/dinamic-localizador/frontend/src/hooks/useAsyncSearchOptions.cache.test.tsx:46:      React.useEffect(() => {
/Users/nasserelbacha/Documents/Dinamic sistems/dinamic-localizador/frontend/src/pages/settings/CompanySettingsPage.tsx:86:  useEffect(() => {
/Users/nasserelbacha/Documents/Dinamic sistems/dinamic-localizador/frontend/src/pages/bot-simulator/hooks/useBotSimulatorSession.ts:53:  useEffect(() => {
/Users/nasserelbacha/Documents/Dinamic sistems/dinamic-localizador/frontend/src/pages/absences/AbsencesListPage.tsx:53:  useEffect(() => {
/Users/nasserelbacha/Documents/Dinamic sistems/dinamic-localizador/frontend/src/pages/platform/observability/WhatsappConversationDetailPage.tsx:168:  useEffect(() => {
/Users/nasserelbacha/Documents/Dinamic sistems/dinamic-localizador/frontend/src/pages/platform/CreatePlatformCompanyDialog.tsx:146:  useEffect(() => {
/Users/nasserelbacha/Documents/Dinamic sistems/dinamic-localizador/frontend/src/pages/invitations/AcceptInvitationPage.tsx:105:  useEffect(() => {
