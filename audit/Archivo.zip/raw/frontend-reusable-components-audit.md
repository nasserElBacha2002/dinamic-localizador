# Frontend reusable components audit

- Button references: 444
- Card references: 24
- Dialog references: 0
- Table references: 151
- Modal references: 4
- Drawer references: 4
- Alert references: 134
- CircularProgress references: 0

## Possible manual UI patterns
/Users/nasserelbacha/Documents/Dinamic sistems/dinamic-localizador/frontend/src/components/company/RolePermissionsDialog.test.tsx:130:      <button type="button" onClick={() => setRole("OPERATOR")}>
/Users/nasserelbacha/Documents/Dinamic sistems/dinamic-localizador/frontend/src/components/company/RolePermissionsDialog.test.tsx:133:      <button type="button" onClick={() => setRole("ADMIN")}>
/Users/nasserelbacha/Documents/Dinamic sistems/dinamic-localizador/frontend/src/components/company/RolePermissionsDialog.test.tsx:344:          <button
/Users/nasserelbacha/Documents/Dinamic sistems/dinamic-localizador/frontend/src/hooks/filter-reset.screens.integration.test.tsx:58:          <button type="button" onClick={() => table.setField("status", "SCHEDULED")}>
/Users/nasserelbacha/Documents/Dinamic sistems/dinamic-localizador/frontend/src/hooks/filter-reset.screens.integration.test.tsx:61:          <button type="button" onClick={() => table.setField("dateFrom", "2026-01-01")}>
/Users/nasserelbacha/Documents/Dinamic sistems/dinamic-localizador/frontend/src/hooks/filter-reset.screens.integration.test.tsx:64:          <button type="button" onClick={() => table.setPage(3)}>
/Users/nasserelbacha/Documents/Dinamic sistems/dinamic-localizador/frontend/src/hooks/filter-reset.screens.integration.test.tsx:67:          <button type="button" onClick={() => table.setPageSize(25)}>
/Users/nasserelbacha/Documents/Dinamic sistems/dinamic-localizador/frontend/src/hooks/filter-reset.screens.integration.test.tsx:70:          <button type="button" onClick={() => table.setSorting("status", "desc")}>
/Users/nasserelbacha/Documents/Dinamic sistems/dinamic-localizador/frontend/src/hooks/filter-reset.screens.integration.test.tsx:73:          <button type="button" onClick={() => table.resetFilters()}>
/Users/nasserelbacha/Documents/Dinamic sistems/dinamic-localizador/frontend/src/hooks/filter-reset.screens.integration.test.tsx:119:          <button
/Users/nasserelbacha/Documents/Dinamic sistems/dinamic-localizador/frontend/src/hooks/filter-reset.screens.integration.test.tsx:134:          <button
/Users/nasserelbacha/Documents/Dinamic sistems/dinamic-localizador/frontend/src/hooks/filter-reset.screens.integration.test.tsx:140:          <button type="button" onClick={() => table.resetFilters()}>
/Users/nasserelbacha/Documents/Dinamic sistems/dinamic-localizador/frontend/src/hooks/filter-reset.screens.integration.test.tsx:221:          <button type="button" onClick={() => table.setField("tab", "employee")}>
/Users/nasserelbacha/Documents/Dinamic sistems/dinamic-localizador/frontend/src/hooks/filter-reset.screens.integration.test.tsx:224:          <button type="button" onClick={() => table.setField("empPage", 4)}>
/Users/nasserelbacha/Documents/Dinamic sistems/dinamic-localizador/frontend/src/hooks/filter-reset.screens.integration.test.tsx:227:          <button type="button" onClick={() => table.setField("opPage", 5)}>
/Users/nasserelbacha/Documents/Dinamic sistems/dinamic-localizador/frontend/src/hooks/filter-reset.screens.integration.test.tsx:230:          <button type="button" onClick={() => table.setField("svcPage", 6)}>
/Users/nasserelbacha/Documents/Dinamic sistems/dinamic-localizador/frontend/src/hooks/filter-reset.screens.integration.test.tsx:233:          <button type="button" onClick={() => table.setField("empPageSize", 25)}>
/Users/nasserelbacha/Documents/Dinamic sistems/dinamic-localizador/frontend/src/hooks/filter-reset.screens.integration.test.tsx:236:          <button
/Users/nasserelbacha/Documents/Dinamic sistems/dinamic-localizador/frontend/src/hooks/filter-reset.screens.integration.test.tsx:242:          <button type="button" onClick={() => table.resetFilters()}>
/Users/nasserelbacha/Documents/Dinamic sistems/dinamic-localizador/frontend/src/hooks/filter-reset.screens.integration.test.tsx:287:          <button
/Users/nasserelbacha/Documents/Dinamic sistems/dinamic-localizador/frontend/src/hooks/filter-reset.screens.integration.test.tsx:293:          <button type="button" onClick={() => table.setField("recordType", "simulation")}>
/Users/nasserelbacha/Documents/Dinamic sistems/dinamic-localizador/frontend/src/hooks/filter-reset.screens.integration.test.tsx:296:          <button type="button" onClick={() => table.resetFilters()}>
/Users/nasserelbacha/Documents/Dinamic sistems/dinamic-localizador/frontend/src/hooks/filter-reset.screens.integration.test.tsx:369:          <button type="button" onClick={() => table.resetFilters()}>
/Users/nasserelbacha/Documents/Dinamic sistems/dinamic-localizador/frontend/src/hooks/filter-reset.screens.integration.test.tsx:450:          <button type="button" onClick={() => table.setField("status", "SCHEDULED")}>
/Users/nasserelbacha/Documents/Dinamic sistems/dinamic-localizador/frontend/src/hooks/filter-reset.screens.integration.test.tsx:453:          <button type="button" onClick={() => table.setField("search", "x")}>
/Users/nasserelbacha/Documents/Dinamic sistems/dinamic-localizador/frontend/src/hooks/filter-reset.screens.integration.test.tsx:456:          <button type="button" onClick={() => table.setPage(3)}>
/Users/nasserelbacha/Documents/Dinamic sistems/dinamic-localizador/frontend/src/hooks/filter-reset.screens.integration.test.tsx:459:          <button
/Users/nasserelbacha/Documents/Dinamic sistems/dinamic-localizador/frontend/src/hooks/table-url-navigation.test.tsx:57:      <button type="button" onClick={() => table.setField("status", "SCHEDULED")}>
/Users/nasserelbacha/Documents/Dinamic sistems/dinamic-localizador/frontend/src/hooks/table-url-navigation.test.tsx:60:      <button
/Users/nasserelbacha/Documents/Dinamic sistems/dinamic-localizador/frontend/src/hooks/table-url-navigation.test.tsx:66:      <button type="button" onClick={() => table.setPage(2)}>
