# Code Audit Summary

Generated at: 2026-08-12T14:36:54Z
Audit version: **3.0**

## Overall status

- Mode: **diagnostic** (`npm run audit` — non-blocking by default)
- Overall status: **ok**
- Blocking status: **pass** (0 blocking)
- Max severity (excluding environment-only): **medium**

## Blocking checks

No blocking failures detected.

## Non-blocking findings

- **backend-circular-imports** (medium): madge found 2 circular dependency chain(s).
- **backend-eslint** (medium): ✖ 58 problems (58 errors, 0 warnings)
- **backend-npm-audit** (medium): npm audit reported 0 critical, 0 high, 5 moderate, 0 low vulnerabilities. Top packages: @google-cloud/storage (moderate), gaxios (moderate), retry-request (moderate).
- **frontend-circular-imports** (medium): madge found 1 circular dependency chain(s).
- **security-env** (medium): Environment variables used in code but missing from .env.example: BOT_DEFAULT_COMPANY_ID, BOT_DEFAULT_COMPANY_NAME, DB_MIGRATION_PASSWORD, DB_MIGRATION_USER, DB_PRIVILEGE_TEST_PASSWORD, DB_PRIVILEGE_TEST_USER, FRONTEND_IMAGE, GCLOUD_PROJECT...
- **backend-architecture** (medium): SQL outside repositories: 185 occurrence(s) to review
- **security-env** (medium): Undocumented env vars: BOT_DEFAULT_COMPANY_ID, BOT_DEFAULT_COMPANY_NAME, DB_MIGRATION_PASSWORD, DB_MIGRATION_USER, DB_PRIVILEGE_TEST_PASSWORD, DB_PRIVILEGE_TEST_USER

## Accepted exceptions

These are informational and do not count as unresolved architectural defects.

- **allowed_operational_sql** (2304): SQL in scripts, migrations, and store utilities
- **repository_sql** (642): SQL inside repository layer (expected)

## Security findings

- Hardcoded secrets: none detected
- Undocumented env vars: **21** (BOT_DEFAULT_COMPANY_ID, BOT_DEFAULT_COMPANY_NAME, DB_MIGRATION_PASSWORD, DB_MIGRATION_USER, DB_PRIVILEGE_TEST_PASSWORD, DB_PRIVILEGE_TEST_USER, FRONTEND_IMAGE, GCLOUD_PROJECT, OWNER_PASSWORD, RUN_DB_INTEGRATION_TESTS)
- security-audit: pass — Security audit artifacts generated
- security-env: fail — Environment variables used in code but missing from .env.example: BOT_DEFAULT_COMPANY_ID, BOT_DEFAULT_COMPANY_NAME, DB_MIGRATION_PASSWORD, DB_MIGRATION_USER, DB_PRIVILEGE_TEST_PASSWORD, DB_PRIVILEGE_TEST_USER, FRONTEND_IMAGE, GCLOUD_PROJECT...

## Architecture findings

- Parameterized SQL: **2238** `.input(...)` bindings across **74** file(s)
- Risky dynamic SQL: none detected
- Repository SQL: **642** occurrence(s)
- SQL outside repositories (warnings): **185**
- backend-circular-imports: madge found 2 circular dependency chain(s).
- frontend-circular-imports: madge found 1 circular dependency chain(s).

## Dependency vulnerabilities

### backend-npm-audit
- Counts: critical=0, high=0, moderate=5, low=0
- `@google-cloud/storage` [moderate]:  (fix available (major bump — review manually))
- `gaxios` [moderate]:  (fix available)
- `retry-request` [moderate]:  (fix available (major bump — review manually))
- `teeny-request` [moderate]:  (fix available (major bump — review manually))
- `uuid` [moderate]: uuid: Missing buffer bounds check in v3/v5/v6 when buf is provided (fix available (major bump — review manually))
- Recommendation: Review lockfile changes before applying fixes. Prefer `npm audit fix` without `--force`. Avoid `--force` unless you can validate major upgrades manually.

## Next actions

1. Review npm audit for **backend-npm-audit**; apply safe fixes only.
2. Resolve architecture finding in **backend-circular-imports**.
3. Resolve architecture finding in **frontend-circular-imports**.
4. Configure or document skipped check **security-env**.

## Baseline status

_No baseline saved yet. Run `npm run audit:baseline` after confirming audit quality._
- Current overall status: **ok**
- Blocking status: **pass**

## Areas

| Area | Status | Max severity | Checks |
|------|--------|--------------|--------|
| frontend | ok | info | 6 |
| backend | findings | medium | 5 |
| frontend_architecture | findings | medium | 4 |
| backend_architecture | findings | medium | 4 |
| security | findings | medium | 3 |
| domain_rules | ok | info | 1 |

## Checks

| Check | Status | Severity | Blocking | Failure type | Message |
|-------|--------|----------|----------|--------------|---------|
| backend-architecture | pass | info | False | unknown | Backend architecture audit generated |
| backend-build | pass | none | False | unknown | Completed successfully |
| backend-circular-imports | fail | medium | False | architecture_issue | Tool reported issues or failed |
| backend-dead-code | pass | none | False | unknown | Tool completed |
| backend-domain-rules | pass | info | False | unknown | Domain rules heuristic audit generated |
| backend-duplication | pass | none | False | unknown | Tool completed |
| backend-eslint | fail | medium | False | tool_failure | Command failed with exit 1 |
| backend-npm-audit | fail | medium | False | dependency_vulnerability | npm audit exit 1 |
| backend-test | pass | none | False | unknown | Completed successfully |
| backend-typecheck | pass | none | False | unknown | tsc --noEmit passed |
| framework-deep-audit | pass | info | False | unknown | Framework findings=231 blocking=0 |
| frontend-architecture | pass | info | False | unknown | Frontend architecture audit generated |
| frontend-build | pass | none | False | unknown | Completed successfully |
| frontend-circular-imports | fail | medium | False | architecture_issue | Tool reported issues or failed |
| frontend-dead-code | pass | none | False | unknown | Tool completed |
| frontend-duplication | pass | none | False | unknown | Tool completed |
| frontend-eslint | pass | none | False | unknown | Completed successfully |
| frontend-heuristics | pass | info | False | unknown | Heuristic frontend audits generated |
| frontend-npm-audit | pass | none | False | unknown | npm audit exit 0 |
| frontend-test | pass | none | False | unknown | Completed successfully |
| frontend-typecheck | pass | none | False | unknown | tsc --noEmit passed |
| security-audit | pass | info | False | unknown | Security audit artifacts generated |
| security-env | fail | medium | False | config_missing | Environment variables used but not documented |
| security-secrets | pass | none | False | unknown | No hardcoded secrets found |
## Root causes

### backend-circular-imports
- Status: fail
- Severity: medium
- Failure type: architecture_issue
- Root cause: madge found 2 circular dependency chain(s).
- Evidence: `audit/raw/backend-import-boundaries.txt`
- Suggested action: Break import cycles by extracting shared modules or inverting dependencies.

### backend-eslint
- Status: fail
- Severity: medium
- Failure type: tool_failure
- Root cause: ✖ 58 problems (58 errors, 0 warnings)
- Evidence: `audit/raw/backend-eslint.txt`
- Suggested action: Fix lint/type errors listed in evidence.

### backend-npm-audit
- Status: fail
- Severity: medium
- Failure type: dependency_vulnerability
- Root cause: npm audit reported 0 critical, 0 high, 5 moderate, 0 low vulnerabilities. Top packages: @google-cloud/storage (moderate), gaxios (moderate), retry-request (moderate).
- Evidence: `audit/raw/backend-npm-audit.json`
- Suggested action: Review lockfile changes before applying fixes. Prefer `npm audit fix` without `--force`. Avoid `--force` unless you can validate major upgrades manually.

### frontend-circular-imports
- Status: fail
- Severity: medium
- Failure type: architecture_issue
- Root cause: madge found 1 circular dependency chain(s).
- Evidence: `audit/raw/frontend-import-boundaries.txt`
- Suggested action: Break import cycles by extracting shared modules or inverting dependencies.

### security-env
- Status: fail
- Severity: medium
- Failure type: config_missing
- Root cause: Environment variables used in code but missing from .env.example: BOT_DEFAULT_COMPANY_ID, BOT_DEFAULT_COMPANY_NAME, DB_MIGRATION_PASSWORD, DB_MIGRATION_USER, DB_PRIVILEGE_TEST_PASSWORD, DB_PRIVILEGE_TEST_USER, FRONTEND_IMAGE, GCLOUD_PROJECT...
- Evidence: `audit/raw/security-env-audit.md`
- Suggested action: Add missing variables to .env.example and backend/.env.example with placeholders.


## Baseline comparison

_No baseline found. Run `npm run audit:baseline` after confirming a good state._

## Evidence files

- `audit/raw/backend-architecture-audit.md`
- `audit/raw/backend-build.txt`
- `audit/raw/backend-code-smells.txt`
- `audit/raw/backend-complexity.txt`
- `audit/raw/backend-dead-code.txt`
- `audit/raw/backend-domain-rules-audit.md`
- `audit/raw/backend-duplication.txt`
- `audit/raw/backend-eslint.txt`
- `audit/raw/backend-import-boundaries.txt`
- `audit/raw/backend-npm-audit.json`
- `audit/raw/backend-sql-analysis.json`
- `audit/raw/backend-test.txt`
- `audit/raw/backend-typecheck.txt`
- `audit/raw/framework-findings.json`
- `audit/raw/frontend-build.txt`
- `audit/raw/frontend-code-smells.txt`
- `audit/raw/frontend-complexity.txt`
- `audit/raw/frontend-dead-code.txt`
- `audit/raw/frontend-duplication.txt`
- `audit/raw/frontend-error-handling-audit.md`
- `audit/raw/frontend-eslint.txt`
- `audit/raw/frontend-import-boundaries.txt`
- `audit/raw/frontend-npm-audit.json`
- `audit/raw/frontend-reusable-components-audit.md`
- `audit/raw/frontend-solid-react-audit.md`
- `audit/raw/frontend-test.txt`
- `audit/raw/frontend-typecheck.txt`
- `audit/raw/frontend-useeffects-audit.md`
- `audit/raw/partial/solid-findings.json`
- `audit/raw/partial/solid-report.md`
- `audit/raw/security-docker-audit.md`
- `audit/raw/security-env-audit.md`
- `audit/raw/security-npm-audit.txt`
- `audit/raw/security-secrets-audit.md`
