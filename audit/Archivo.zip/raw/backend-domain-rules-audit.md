# Backend domain rules audit

## Parameterized SQL (mssql)

Scans `backend/src/**/*.ts` production code for `mssql` parameter bindings.

- Files with `.input(...)` bindings: **74**
- Parameter binding occurrences: **2238**
- Files executing SQL (`.query`/`.batch`/`.execute`): **77**
- SQL execution call sites: **666**

- Evidence: backend uses `mssql` parameter bindings via `.input(...)`.

### Sample files with parameter bindings
- `backend/src/database/run-migrations.ts`
- `backend/src/repositories/absence-attachment.repository.ts`
- `backend/src/repositories/absence-balance-ledger.repository.ts`
- `backend/src/repositories/absence-balance.repository.ts`
- `backend/src/repositories/absence-calendar.repository.ts`
- `backend/src/repositories/absence-operational-impact.repository.ts`
- `backend/src/repositories/absence-request-draft.repository.ts`
- `backend/src/repositories/absence-request.repository.ts`
- `backend/src/repositories/absence-type.repository.ts`
- `backend/src/repositories/absence-workday-sync-job.repository.ts`
- `backend/src/repositories/attendance-notification.repository.ts`
- `backend/src/repositories/attendance-review.repository.ts`
- ... and 62 more

## Dynamic SQL risk review

- No risky interpolated SQL detected in scanned production files.

## Other domain heuristics

- Twilio MessageSid idempotency: 552 matches
- Bot session handling: 475 matches
- Session expiration: 426 matches
- Check-in flow: 390 matches
- Check-out flow: 841 matches
- Geofencing/Haversine: 253 matches
- Timezone usage: 732 matches
- Inventory assignment validation: 3 matches
- Inventory time window: 147 matches
- Reminder deduplication: 36 matches

## Migrations

- `database/migrations/001_initial_schema.sql`
- `database/migrations/002_core_domain.sql`
- `database/migrations/003_whatsapp_bot_flow.sql`
- `database/migrations/004_mvp_completion.sql`
- `database/migrations/005_store_location_fields.sql`
- `database/migrations/006_employee_type.sql`
- `database/migrations/007_attendance_checkout.sql`
- `database/migrations/008_rename_store_columns.sql`
- `database/migrations/009_absence_requests.sql`
- `database/migrations/010_employee_absence_balances.sql`
- `database/migrations/011_whatsapp_attendance_notifications.sql`
- `database/migrations/012_whatsapp_attendance_notification_retries.sql`
- `database/migrations/013_bot_simulator.sql`
- `database/migrations/014_bot_sessions_simulation.sql`
- `database/migrations/015_multi_company_foundation.sql`
- `database/migrations/016_platform_superadmin.sql`
- `database/migrations/017_company_modules.sql`
- `database/migrations/018_multi_company_backfill_validation.sql`
- `database/migrations/019_companies_name_unique.sql`
- `database/migrations/020_company_settings_company_unique.sql`
- `database/migrations/021_physical_operational_table_rename.sql`
- `database/migrations/022_no_checkin_at_start_notification.sql`
- `database/migrations/023_assignment_confirmation_status.sql`
- `database/migrations/024_bot_session_assignment_selection_states.sql`
- `database/migrations/025_task5_drop_response_note.sql`
- `database/migrations/026_company_operational_defaults.sql`
- `database/migrations/027_align_inventory_late_default_with_whatsapp.sql`
- `database/migrations/028_company_absence_catalog_backfill.sql`
- `database/migrations/029_company_location_types_store_format_constraint.sql`
- `database/migrations/030_company_confirmation_reminder_settings.sql`
- `database/migrations/031_attendance_confirmation_reminder_notification.sql`
- `database/migrations/032_assignment_confirmation_schedule_version.sql`
- `database/migrations/033_attendance_notification_sent_recovery_status.sql`
- `database/migrations/034_widen_attendance_notification_status.sql`
- `database/migrations/035_rename_operational_foreign_key_columns.sql`
- `database/migrations/036_operational_domain_permission_audit_backfill.sql`
- `database/migrations/037_domain_rename_completion.sql`
- `database/migrations/038_finalize_company_module_key_migration.sql`
- `database/migrations/039_workday_domain_foundation.sql`
- `database/migrations/040_temporal_operation_assignments.sql`
- `database/migrations/041_assignment_cancellation.sql`
- `database/migrations/042_recurring_schedule_foundation.sql`
- `database/migrations/043_recurring_schedule_timezone_semantics.sql`
- `database/migrations/044_recurring_workday_materialization.sql`
- `database/migrations/045_workday_cancellation_provenance.sql`
- `database/migrations/046_employee_workday_absence_integration.sql`
- `database/migrations/047_bot_session_workday_identity.sql`
- `database/migrations/048_company_pending_operation_expiration.sql`
- `database/migrations/048_operational_locations_company_name_unique.sql`
- `database/migrations/049_operational_locations_name_uniqueness_hardening.sql`
- `database/migrations/050_work_teams.sql`
- `database/migrations/051_work_team_assignment_batches.sql`
- `database/migrations/052_work_teams_review_fixes.sql`
- `database/migrations/053_operational_locations_list_filters_hardening.sql`
- `database/migrations/054_employee_categories.sql`
- `database/migrations/055_employee_categories_company_scope_trigger.sql`
- `database/migrations/056_drop_legacy_store_format_check.sql`
- `database/migrations/057_import_jobs.sql`
- `database/migrations/058_user_invitations.sql`
- `database/migrations/059_user_invitations_delivery_version.sql`
- `database/migrations/060_user_invitations_declined_status.sql`
- `database/migrations/061_absence_phase0_hardening_corrections.sql`
- `database/migrations/062_absence_phase2_work_calendars.sql`
- `database/migrations/063_absence_phase2_calendar_corrections.sql`
- `database/migrations/064_absence_phase3_balance_ledger.sql`
- `database/migrations/065_absence_phase3_ledger_corrections.sql`
- `database/migrations/066_absence_phase4_gcs_attachments.sql`
- `database/migrations/067_absence_phase4_attachment_corrections.sql`
- `database/migrations/068_absence_attachment_pending_size.sql`
- `database/migrations/069_absence_phase5_operational_integration.sql`
- `database/migrations/070_absence_phase5_operational_corrections.sql`
- `database/migrations/071_absence_phase5_closure_atomic_leases.sql`
- `database/migrations/072_absence_phase5_lease_fencing.sql`
- `database/migrations/073_absence_phase6_whatsapp_foundation.sql`
- `database/migrations/074_absence_phase6_webhook_durable_claim.sql`
- `database/migrations/075_attendance_notification_superseded_status.sql`
- `database/migrations/076_whatsapp_observability_foundation.sql`
- `database/migrations/077_whatsapp_observability_corrections.sql`
- `database/migrations/078_whatsapp_observability_message_cursor_index.sql`
- `database/migrations/079_company_lifecycle_deletion.sql`
- `database/migrations/080_company_lifecycle_hardening.sql`
- `database/migrations/081_payroll_receipts.sql`
- `database/migrations/082_payroll_receipts_hardening.sql`
- `database/migrations/083_payroll_receipt_whatsapp_notifications.sql`
- `database/migrations/084_payroll_receipt_whatsapp_corrections.sql`
- `database/migrations/085_user_company_membership_default_unique.sql`
- `database/migrations/086_attendance_reviews_unique_per_attendance.sql`
- `database/migrations/086_payroll_multiple_receipts_per_period.sql`
- `database/migrations/087_phase1_tenant_composite_fks.sql`
- `database/migrations/088_phase1_work_team_members_contract.sql`
- `database/migrations/089_phase3_4_db_security_roles.sql`
- `database/migrations/090_phase3_4_revoke_schema_execute.sql`
- `database/migrations/091_operation_assignment_whatsapp_notifications.sql`
