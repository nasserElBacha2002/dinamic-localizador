# Backend architecture audit

## SQL location classification

Scanned paths:
- `backend/src/**/*.ts` (production TypeScript)
- `database/**/*.sql`, `database/**/*.ts`
- `scripts/**/*.{ts,sh}`

Accepted exceptions are informational only and do not count as architectural warnings.

### Allowed operational SQL (info) — 2304 occurrence(s)
- `backend/src/database/db-probe.ts:6` `await getPool().request().query("SELECT 1 AS ok");`
- `backend/src/database/operational-location-duplicate-remediation.ts:5` `SELECT`
- `backend/src/database/operational-location-duplicate-remediation.ts:14` `SELECT COUNT(*)`
- `backend/src/database/operational-location-duplicate-remediation.ts:23` `SELECT COUNT(*)`
- `backend/src/database/operational-location-duplicate-remediation.ts:35` `SELECT 1`
- `backend/src/database/operational-location-duplicate-remediation.ts:52` `SELECT`
- `backend/src/database/operational-location-duplicate-remediation.ts:61` `SELECT`
- `backend/src/database/operational-location-duplicate-remediation.ts:69` `SELECT COUNT(*)`
- `backend/src/database/operational-location-duplicate-remediation.ts:84` `SELECT`
- `backend/src/database/operational-location-duplicate-remediation.ts:92` `SELECT`
- `backend/src/database/operational-location-duplicate-remediation.ts:102` `UPDATE ol`
- `backend/src/database/run-migrations.ts:43` `SELECT 1 AS found`
- `backend/src/database/run-migrations.ts:53` `SELECT migration_name`
- `backend/src/database/run-migrations.ts:97` `INSERT INTO system_migrations (migration_name)`
- `backend/src/scripts/audit-operational-rename-schema.ts:50` `await pool.request().query("SELECT TOP 1 * FROM dbo.stores");`
- `backend/src/scripts/audit-operational-rename-schema.ts:51` `await pool.request().query("SELECT TOP 1 * FROM dbo.inventories");`
- `backend/src/scripts/audit-operational-rename-schema.ts:52` `await pool.request().query("SELECT TOP 1 * FROM dbo.inventory_employees");`
- `backend/src/scripts/audit-statistics-grain-core.ts:40` `SELECT c.id AS company_id`
- `backend/src/scripts/audit-statistics-grain-core.ts:45` `SELECT ar.company_id, ar.employee_workday_id`
- `backend/src/scripts/audit-statistics-grain-core.ts:52` `SELECT company_id, employee_workday_id`
- `backend/src/scripts/audit-statistics-grain-core.ts:58` `SELECT`
- `backend/src/scripts/audit-statistics-grain-core.ts:61` `SELECT COUNT(*)`
- `backend/src/scripts/audit-statistics-grain-core.ts:66` `SELECT COUNT(*)`
- `backend/src/scripts/audit-statistics-grain-core.ts:73` `SELECT COUNT(*)`
- `backend/src/scripts/audit-statistics-grain-core.ts:80` `SELECT COUNT(*)`
- ... and 2279 more

### Allowed healthcheck SQL (info) — 0 occurrence(s)
- None

### Repository SQL (expected) (info) — 642 occurrence(s)
- `backend/src/repositories/absence-attachment.repository.ts:119` `INSERT INTO absence_request_attachments (`
- `backend/src/repositories/absence-attachment.repository.ts:150` `SELECT TOP 1 *`
- `backend/src/repositories/absence-attachment.repository.ts:174` `SELECT TOP 1 *`
- `backend/src/repositories/absence-attachment.repository.ts:198` `SELECT *`
- `backend/src/repositories/absence-attachment.repository.ts:220` `SELECT *`
- `backend/src/repositories/absence-attachment.repository.ts:243` `SELECT COUNT(1) AS cnt`
- `backend/src/repositories/absence-attachment.repository.ts:259` `SELECT COUNT(1) AS cnt`
- `backend/src/repositories/absence-attachment.repository.ts:292` `UPDATE absence_request_attachments`
- `backend/src/repositories/absence-attachment.repository.ts:333` `SELECT TOP 1 id`
- `backend/src/repositories/absence-attachment.repository.ts:364` `SELECT`
- `backend/src/repositories/absence-attachment.repository.ts:435` `SELECT TOP 1 *`
- `backend/src/repositories/absence-attachment.repository.ts:459` `SELECT COALESCE(SUM(CAST(size_bytes AS BIGINT)), 0) AS total_bytes`
- `backend/src/repositories/absence-attachment.repository.ts:485` `UPDATE absence_request_attachments`
- `backend/src/repositories/absence-attachment.repository.ts:532` `UPDATE absence_request_attachments`
- `backend/src/repositories/absence-attachment.repository.ts:581` `UPDATE absence_request_attachments`
- `backend/src/repositories/absence-attachment.repository.ts:610` `SELECT TOP 1 *`
- `backend/src/repositories/absence-attachment.repository.ts:633` `SELECT TOP 1 *`
- `backend/src/repositories/absence-attachment.repository.ts:655` `SELECT TOP 1 *`
- `backend/src/repositories/absence-attachment.repository.ts:669` `SELECT TOP 1 *`
- `backend/src/repositories/absence-attachment.repository.ts:700` `SELECT TOP 1 *`
- `backend/src/repositories/absence-attachment.repository.ts:720` `UPDATE absence_request_attachments`
- `backend/src/repositories/absence-attachment.repository.ts:755` `SELECT TOP (@limit) *`
- `backend/src/repositories/absence-balance-ledger.repository.ts:70` `SELECT TOP 1 *`
- `backend/src/repositories/absence-balance-ledger.repository.ts:90` `SELECT TOP 1 *`
- `backend/src/repositories/absence-balance-ledger.repository.ts:137` `INSERT INTO employee_absence_balance_movements (`
- ... and 617 more

### SQL outside repositories (review) (warning) — 185 occurrence(s)
- `backend/src/services/absence-balance.service.ts:414` `UPDATE employee_absence_balances`
- `backend/src/services/absence-request-draft.service.ts:115` `INSERT INTO absence_request_drafts (`
- `backend/src/services/absence-request-draft.service.ts:137` `SELECT TOP 1 * FROM absence_request_drafts`
- `backend/src/services/absence-request-draft.service.ts:204` `UPDATE absence_request_drafts`
- `backend/src/services/absence-request-draft.service.ts:218` `UPDATE absence_request_attachments`
- `backend/src/services/company-data-cascade.service.ts:14` `UPDATE operation_assignments`
- `backend/src/services/company-data-cascade.service.ts:18` `UPDATE work_team_assignment_batch_items`
- `backend/src/services/company-data-cascade.service.ts:21` `SELECT id FROM work_team_assignment_batches WHERE company_id = @companyId`
- `backend/src/services/company-data-cascade.service.ts:24` `DELETE FROM work_team_assignment_batch_item_sources`
- `backend/src/services/company-data-cascade.service.ts:26` `SELECT i.id`
- `backend/src/services/company-data-cascade.service.ts:32` `DELETE FROM work_team_assignment_batch_items`
- `backend/src/services/company-data-cascade.service.ts:35` `DELETE FROM work_team_assignment_batch_teams`
- `backend/src/services/company-data-cascade.service.ts:38` `DELETE FROM work_team_assignment_batches WHERE company_id = @companyId;`
- `backend/src/services/company-data-cascade.service.ts:40` `DELETE FROM attendance_records WHERE company_id = @companyId;`
- `backend/src/services/company-data-cascade.service.ts:41` `DELETE FROM whatsapp_attendance_notifications WHERE company_id = @companyId;`
- `backend/src/services/company-data-cascade.service.ts:43` `DELETE FROM whatsapp_payroll_receipt_notifications WHERE company_id = @companyId;`
- `backend/src/services/company-data-cascade.service.ts:45` `DELETE FROM whatsapp_operation_assignment_notification_send_attempts`
- `backend/src/services/company-data-cascade.service.ts:48` `DELETE FROM whatsapp_operation_assignment_notifications WHERE company_id = @companyId;`
- `backend/src/services/company-data-cascade.service.ts:49` `DELETE FROM bot_sessions WHERE company_id = @companyId;`
- `backend/src/services/company-data-cascade.service.ts:50` `DELETE FROM bot_simulation_sessions WHERE company_id = @companyId;`
- `backend/src/services/company-data-cascade.service.ts:52` `DELETE FROM employee_workdays WHERE company_id = @companyId;`
- `backend/src/services/company-data-cascade.service.ts:53` `DELETE FROM operation_assignments WHERE company_id = @companyId;`
- `backend/src/services/company-data-cascade.service.ts:54` `DELETE FROM operation_workdays WHERE company_id = @companyId;`
- `backend/src/services/company-data-cascade.service.ts:56` `DELETE FROM operation_schedule_days`
- `backend/src/services/company-data-cascade.service.ts:58` `SELECT id FROM operation_schedules WHERE company_id = @companyId`
- ... and 160 more

## Summary: warning_sql_outside_repository = **185**

## Frontend imports in backend
None detected
