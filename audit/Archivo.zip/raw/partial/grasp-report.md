# Audit report

Generated: 2026-08-12T14:37:15.784557+00:00
Run ID: `20260812-143715`
Run type: `partial`
Completed: `True`
Selected scanners: `grasp`

## Executive summary

- Findings: **3**
- Critical: 0 | High: 0 | Medium: 3 | Low: 0 | Info: 0
- Gate: PASSED (blocking=0)

### By category

- grasp: 3

## Scanner coverage

### Framework (normalized into findings)

- architecture
- god-classes
- complexity
- sql
- solid
- grasp
- patches
- exceptions
- reliability
- env-consistency

### Legacy (not fully normalized into findings.json)

- npm audit
- secrets
- env documentation
- docker security
- security deep
- madge circular
- jscpd duplication
- ts-prune dead exports
- tenant isolation script
- backend/frontend lint/typecheck/test/build

## Finding hotspot score

Formula: `sum(severity_weight) + god_class.score` per file.
Not a change-risk score (churn/coverage/history not included).

- `12` `backend/src/controllers/twilio-webhook.controller.ts` (1 findings, max=medium)
- `12` `backend/src/services/bot-session.service.ts` (1 findings, max=medium)
- `12` `backend/src/services/whatsapp-flow-trace.service.ts` (1 findings, max=medium)

## Grasp

- **[medium/medium/requires-review]** `grasp-ctrl-f5e1985641` — Controller doing too much (GRASP) (`backend/src/controllers/twilio-webhook.controller.ts`)
  - Controller shows SQL/business branching/external calls.
  - Recommendation: Keep controllers thin: validate → service → map response.
  - Blocking: False
- **[medium/low/suspected]** `cohesion-87f11f7396` — Low cohesion candidate (`backend/src/services/bot-session.service.ts`)
  - Service touches domains ['attendance', 'employee', 'payroll', 'company', 'notification'] with ~21 methods.
  - Recommendation: Split by bounded context if method clusters are independent.
  - Blocking: False
- **[medium/low/suspected]** `cohesion-be4443de2f` — Low cohesion candidate (`backend/src/services/whatsapp-flow-trace.service.ts`)
  - Service touches domains ['attendance', 'employee', 'payroll', 'whatsapp', 'assignment', 'store', 'company', 'notification', 'conversation'] with ~15 methods.
  - Recommendation: Split by bounded context if method clusters are independent.
  - Blocking: False
