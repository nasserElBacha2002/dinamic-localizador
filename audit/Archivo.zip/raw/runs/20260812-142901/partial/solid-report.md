# Audit report

Generated: 2026-08-12T14:28:42.202236+00:00
Run ID: `20260812-142842`
Run type: `partial`
Completed: `True`
Selected scanners: `solid`

## Executive summary

- Findings: **28**
- Critical: 0 | High: 0 | Medium: 21 | Low: 7 | Info: 0
- Gate: PASSED (blocking=0)

### By category

- solid: 28

## Scanner coverage

### Framework (normalized into findings)

- architecture
- god-classes
- complexity
- sql
- solid
- grasp
- patches
- exceptions
- reliability
- env-consistency

### Legacy (not fully normalized into findings.json)

- npm audit
- secrets
- env documentation
- docker security
- security deep
- madge circular
- jscpd duplication
- ts-prune dead exports
- tenant isolation script
- backend/frontend lint/typecheck/test/build

## Finding hotspot score

Formula: `sum(severity_weight) + god_class.score` per file.
Not a change-risk score (churn/coverage/history not included).

- `12` `backend/src/repositories/absence-operational-impact.repository.ts` (1 findings, max=medium)
- `12` `backend/src/repositories/absence-request.repository.ts` (1 findings, max=medium)
- `12` `backend/src/repositories/attendance-notification.repository.ts` (1 findings, max=medium)
- `12` `backend/src/repositories/attendance.repository.ts` (1 findings, max=medium)
- `12` `backend/src/repositories/bot-session.repository.ts` (1 findings, max=medium)
- `12` `backend/src/repositories/employee-workday.repository.ts` (1 findings, max=medium)
- `12` `backend/src/repositories/employee.repository.ts` (1 findings, max=medium)
- `12` `backend/src/repositories/operation-assignment-notification.repository.ts` (1 findings, max=medium)
- `12` `backend/src/repositories/operation-employee.repository.ts` (1 findings, max=medium)
- `12` `backend/src/repositories/operation-workday.repository.ts` (1 findings, max=medium)
- `12` `backend/src/repositories/operation.repository.ts` (1 findings, max=medium)
- `12` `backend/src/repositories/payroll-receipt-notification.repository.ts` (1 findings, max=medium)
- `12` `backend/src/repositories/payroll-receipt.repository.ts` (1 findings, max=medium)
- `12` `backend/src/repositories/whatsapp-observability.repository.ts` (1 findings, max=medium)
- `12` `backend/src/repositories/work-team-assignment-batch.repository.ts` (1 findings, max=medium)
- `12` `backend/src/repositories/work-team.repository.ts` (1 findings, max=medium)
- `12` `backend/src/services/company.service.ts` (1 findings, max=medium)
- `12` `backend/src/services/operation.service.ts` (1 findings, max=medium)
- `12` `backend/src/services/whatsapp-bot.service.ts` (1 findings, max=medium)
- `12` `backend/src/services/whatsapp-flow-trace.service.ts` (1 findings, max=medium)

## Solid

- **[medium/low/suspected]** `srp-b094c19efc` — SUSPECTED SRP violation (`backend/src/repositories/absence-operational-impact.repository.ts`)
  - Multiple responsibility signals (3) in one module with ~12 methods / domains=['attendance', 'employee', 'assignment', 'company'].
  - Recommendation: Confirm mixed concerns; extract collaborators if validated.
  - Blocking: False
- **[medium/low/suspected]** `srp-3dcbdd3962` — SUSPECTED SRP violation (`backend/src/repositories/absence-request.repository.ts`)
  - Multiple responsibility signals (3) in one module with ~15 methods / domains=['employee', 'assignment', 'company'].
  - Recommendation: Confirm mixed concerns; extract collaborators if validated.
  - Blocking: False
- **[medium/low/suspected]** `srp-36f432341f` — SUSPECTED SRP violation (`backend/src/repositories/attendance-notification.repository.ts`)
  - Multiple responsibility signals (3) in one module with ~23 methods / domains=['attendance', 'employee', 'whatsapp', 'assignment', 'company', 'notification', 'conversation', 'reminder'].
  - Recommendation: Confirm mixed concerns; extract collaborators if validated.
  - Blocking: False
- **[medium/low/suspected]** `srp-6db2b0df8c` — SUSPECTED SRP violation (`backend/src/repositories/attendance.repository.ts`)
  - Multiple responsibility signals (3) in one module with ~14 methods / domains=['attendance', 'employee', 'assignment', 'company'].
  - Recommendation: Confirm mixed concerns; extract collaborators if validated.
  - Blocking: False
- **[medium/low/suspected]** `srp-d803178097` — SUSPECTED SRP violation (`backend/src/repositories/bot-session.repository.ts`)
  - Multiple responsibility signals (3) in one module with ~11 methods / domains=['attendance', 'employee', 'whatsapp', 'company'].
  - Recommendation: Confirm mixed concerns; extract collaborators if validated.
  - Blocking: False
- **[medium/low/suspected]** `srp-f12b14762c` — SUSPECTED SRP violation (`backend/src/repositories/employee-workday.repository.ts`)
  - Multiple responsibility signals (3) in one module with ~35 methods / domains=['attendance', 'employee', 'assignment', 'store', 'company'].
  - Recommendation: Confirm mixed concerns; extract collaborators if validated.
  - Blocking: False
- **[medium/low/suspected]** `srp-cefb094142` — SUSPECTED SRP violation (`backend/src/repositories/employee.repository.ts`)
  - Multiple responsibility signals (3) in one module with ~13 methods / domains=['attendance', 'employee', 'assignment', 'company'].
  - Recommendation: Confirm mixed concerns; extract collaborators if validated.
  - Blocking: False
- **[medium/low/suspected]** `srp-82d5be65a7` — SUSPECTED SRP violation (`backend/src/repositories/operation-assignment-notification.repository.ts`)
  - Multiple responsibility signals (3) in one module with ~17 methods / domains=['employee', 'whatsapp', 'assignment', 'company', 'notification'].
  - Recommendation: Confirm mixed concerns; extract collaborators if validated.
  - Blocking: False
- **[medium/low/suspected]** `srp-f16791ecc8` — SUSPECTED SRP violation (`backend/src/repositories/operation-employee.repository.ts`)
  - Multiple responsibility signals (3) in one module with ~19 methods / domains=['attendance', 'employee', 'assignment', 'company'].
  - Recommendation: Confirm mixed concerns; extract collaborators if validated.
  - Blocking: False
- **[medium/low/suspected]** `srp-184f87353d` — SUSPECTED SRP violation (`backend/src/repositories/operation-workday.repository.ts`)
  - Multiple responsibility signals (3) in one module with ~18 methods / domains=['attendance', 'employee', 'store', 'company', 'reminder'].
  - Recommendation: Confirm mixed concerns; extract collaborators if validated.
  - Blocking: False
- **[medium/low/suspected]** `srp-58b846a414` — SUSPECTED SRP violation (`backend/src/repositories/operation.repository.ts`)
  - Multiple responsibility signals (3) in one module with ~14 methods / domains=['attendance', 'employee', 'assignment', 'store', 'company'].
  - Recommendation: Confirm mixed concerns; extract collaborators if validated.
  - Blocking: False
- **[medium/low/suspected]** `srp-b2cd8d932b` — SUSPECTED SRP violation (`backend/src/repositories/payroll-receipt-notification.repository.ts`)
  - Multiple responsibility signals (3) in one module with ~19 methods / domains=['employee', 'payroll', 'whatsapp', 'company', 'notification'].
  - Recommendation: Confirm mixed concerns; extract collaborators if validated.
  - Blocking: False
- **[medium/low/suspected]** `srp-5a58f14f60` — SUSPECTED SRP violation (`backend/src/repositories/payroll-receipt.repository.ts`)
  - Multiple responsibility signals (3) in one module with ~18 methods / domains=['employee', 'payroll', 'whatsapp', 'store', 'company', 'notification'].
  - Recommendation: Confirm mixed concerns; extract collaborators if validated.
  - Blocking: False
- **[medium/low/suspected]** `srp-386f094167` — SUSPECTED SRP violation (`backend/src/repositories/whatsapp-observability.repository.ts`)
  - Multiple responsibility signals (3) in one module with ~10 methods / domains=['attendance', 'employee', 'whatsapp', 'company', 'notification', 'conversation'].
  - Recommendation: Confirm mixed concerns; extract collaborators if validated.
  - Blocking: False
- **[medium/low/suspected]** `srp-1b25ce9420` — SUSPECTED SRP violation (`backend/src/repositories/work-team-assignment-batch.repository.ts`)
  - Multiple responsibility signals (3) in one module with ~17 methods / domains=['employee', 'assignment', 'company'].
  - Recommendation: Confirm mixed concerns; extract collaborators if validated.
  - Blocking: False
- **[medium/low/suspected]** `srp-2b3e8aa702` — SUSPECTED SRP violation (`backend/src/repositories/work-team.repository.ts`)
  - Multiple responsibility signals (3) in one module with ~15 methods / domains=['employee', 'assignment', 'company'].
  - Recommendation: Confirm mixed concerns; extract collaborators if validated.
  - Blocking: False
- **[low/low/suspected]** `dip-b8349468c8` — Concrete infrastructure constructed in application layer (`backend/src/services/attachment-storage/gcs-attachment-storage.ts`)
  - new <InfraClient>() found in service/controller. Factories/DI may be preferable.
  - Recommendation: Prefer injected ports; allow factories at composition root.
  - Blocking: False
- **[low/low/suspected]** `ocp-1e3066002c` — Repeated type/provider branching (OCP risk) (`backend/src/services/attendance-reminder.service.ts`)
  - Found ~0 type-switches and ~14 type-ifs. Structural repetition may need strategy pattern.
  - Recommendation: Only refactor if branching keeps growing across providers.
  - Blocking: False
- **[low/low/suspected]** `ocp-676c8816d9` — Repeated type/provider branching (OCP risk) (`backend/src/services/bot/direct-attendance-location.service.ts`)
  - Found ~0 type-switches and ~7 type-ifs. Structural repetition may need strategy pattern.
  - Recommendation: Only refactor if branching keeps growing across providers.
  - Blocking: False
- **[medium/low/suspected]** `srp-880cdc5a55` — SUSPECTED SRP violation (`backend/src/services/company.service.ts`)
  - Multiple responsibility signals (3) in one module with ~13 methods / domains=['attendance', 'company', 'geofence', 'reminder'].
  - Recommendation: Confirm mixed concerns; extract collaborators if validated.
  - Blocking: False
- **[low/low/suspected]** `ocp-6b1b3b62e2` — Repeated type/provider branching (OCP risk) (`backend/src/services/operation-assignment-core.service.ts`)
  - Found ~0 type-switches and ~4 type-ifs. Structural repetition may need strategy pattern.
  - Recommendation: Only refactor if branching keeps growing across providers.
  - Blocking: False
- **[medium/low/suspected]** `srp-f3d23039eb` — SUSPECTED SRP violation (`backend/src/services/operation.service.ts`)
  - Multiple responsibility signals (3) in one module with ~12 methods / domains=['attendance', 'employee', 'assignment', 'store', 'company', 'notification'].
  - Recommendation: Confirm mixed concerns; extract collaborators if validated.
  - Blocking: False
- **[medium/low/suspected]** `srp-8c435db883` — SUSPECTED SRP violation (`backend/src/services/whatsapp-bot.service.ts`)
  - Multiple responsibility signals (3) in one module with ~12 methods / domains=['attendance', 'employee', 'payroll', 'whatsapp', 'inventory', 'company', 'conversation', 'geofence'].
  - Recommendation: Confirm mixed concerns; extract collaborators if validated.
  - Blocking: False
- **[medium/low/suspected]** `srp-be4443de2f` — SUSPECTED SRP violation (`backend/src/services/whatsapp-flow-trace.service.ts`)
  - Multiple responsibility signals (3) in one module with ~15 methods / domains=['attendance', 'employee', 'payroll', 'whatsapp', 'assignment', 'store', 'company', 'notification', 'conversation'].
  - Recommendation: Confirm mixed concerns; extract collaborators if validated.
  - Blocking: False
- **[low/low/suspected]** `ocp-5138e2ba35` — Repeated type/provider branching (OCP risk) (`backend/src/services/whatsapp-router/attendance-confirmation-response.handler.ts`)
  - Found ~0 type-switches and ~4 type-ifs. Structural repetition may need strategy pattern.
  - Recommendation: Only refactor if branching keeps growing across providers.
  - Blocking: False
- **[low/low/suspected]** `ocp-845ec20834` — Repeated type/provider branching (OCP risk) (`backend/src/services/whatsapp-router/payroll-receipt.handler.ts`)
  - Found ~0 type-switches and ~5 type-ifs. Structural repetition may need strategy pattern.
  - Recommendation: Only refactor if branching keeps growing across providers.
  - Blocking: False
- **[medium/low/suspected]** `srp-03728dc63f` — SUSPECTED SRP violation (`backend/src/services/work-team.service.ts`)
  - Multiple responsibility signals (3) in one module with ~11 methods / domains=['employee', 'assignment', 'company'].
  - Recommendation: Confirm mixed concerns; extract collaborators if validated.
  - Blocking: False
- **[low/low/suspected]** `ocp-c760e54b9a` — Repeated type/provider branching (OCP risk) (`backend/src/utils/service-fix/plan.ts`)
  - Found ~0 type-switches and ~6 type-ifs. Structural repetition may need strategy pattern.
  - Recommendation: Only refactor if branching keeps growing across providers.
  - Blocking: False
