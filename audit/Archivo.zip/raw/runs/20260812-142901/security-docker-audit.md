# Docker security audit

## docker-compose.yml
137:      GOOGLE_APPLICATION_CREDENTIALS: ${GOOGLE_APPLICATION_CREDENTIALS:-/app/secrets/gcp-service-account.json}
151:      # GCP ADC for absence attachments (host: repo secrets/ → /app/secrets/)
152:      - ./secrets:/app/secrets:ro

## docker-compose.prod.yml
99:      - ./secrets:/app/secrets:ro

## backend/Dockerfile
- INFO: No HEALTHCHECK in backend/Dockerfile (may be defined in docker-compose.prod.yml).

## frontend/Dockerfile
- INFO: No HEALTHCHECK in frontend/Dockerfile (may be defined in docker-compose.prod.yml).

- .dockerignore present
