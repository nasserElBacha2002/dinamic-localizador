# Security secrets audit

Heuristic scan for hardcoded secrets (values masked).

No obvious hardcoded secrets detected.

## Potential false-positive references ignored

- backend/src/config/env-migrations.ts:18 env/config reference ignored
- backend/src/config/env-migrations.ts:59 reference-only pattern ignored
- backend/src/config/env.ts:157 reference-only pattern ignored
- backend/src/config/env.ts:160 env/config reference ignored
- backend/src/config/env.ts:161 reference-only pattern ignored
- backend/src/config/env.ts:21 env/config reference ignored
- backend/src/config/env.ts:25 env/config reference ignored
- backend/src/config/env.ts:423 reference-only pattern ignored
- backend/src/config/env.ts:46 env/config reference ignored
- backend/src/config/migration-db-credentials.ts:22 reference-only pattern ignored
- backend/src/config/migration-db-credentials.ts:32 reference-only pattern ignored
- backend/src/config/migration-db-credentials.ts:47 reference-only pattern ignored
- backend/src/config/migration-db-credentials.ts:52 reference-only pattern ignored
- backend/src/config/migration-db-credentials.ts:6 env/config reference ignored
- backend/src/database/connection.ts:9 env/config reference ignored
- backend/src/database/run-migrations.ts:34 env/config reference ignored
- backend/src/repositories/user.repository.ts:11 env/config reference ignored
- backend/src/repositories/user.repository.ts:20 env/config reference ignored
- backend/src/repositories/user.repository.ts:23 env/config reference ignored
- backend/src/repositories/user.repository.ts:25 env/config reference ignored
- backend/src/repositories/user.repository.ts:69 env/config reference ignored
- backend/src/repositories/user.repository.ts:74 env/config reference ignored
- backend/src/repositories/user.repository.ts:77 env/config reference ignored
- backend/src/routes/twilio.routes.ts:12 env/config reference ignored
- backend/src/routes/twilio.routes.ts:20 env/config reference ignored
- backend/src/scripts/audit-operational-rename-schema.ts:32 env/config reference ignored
- backend/src/scripts/create-admin.ts:28 env/config reference ignored
- backend/src/scripts/create-admin.ts:31 env/config reference ignored
- backend/src/scripts/create-admin.ts:39 env/config reference ignored
- backend/src/scripts/reconcile-absence-balance-ledger.ts:17 env/config reference ignored
- backend/src/scripts/seed-integration-ci.ts:128 env/config reference ignored
- backend/src/scripts/seed-integration-ci.ts:133 env/config reference ignored
- backend/src/scripts/seed-integration-ci.ts:135 env/config reference ignored
- backend/src/scripts/seed-integration-ci.ts:137 env/config reference ignored
- backend/src/scripts/seed-integration-ci.ts:38 env/config reference ignored
- backend/src/scripts/seed-integration-ci.ts:43 env/config reference ignored
- backend/src/scripts/seed-integration-ci.ts:45 env/config reference ignored
- backend/src/scripts/seed-integration-ci.ts:47 env/config reference ignored
- backend/src/scripts/verify-077-observability-rollback.ts:73 env/config reference ignored
- backend/src/scripts/verify-twilio-signature.ts:33 env/config reference ignored
- ... and 14 more ignored references
